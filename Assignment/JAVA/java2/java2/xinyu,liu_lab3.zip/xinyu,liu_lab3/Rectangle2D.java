/*CSCI1101-Lab3-exercise1
the program is to determine the rectangle by a point  and size of that
<Xinyu,Liu><B00783546><2018.2.2>*/
public class Rectangle2D {
 //attributes:instance variables
  public double xpos,ypos; 
  public double width,height;
 
  //constructor
  public Rectangle2D(){
    this(0.0,0.0,0.0,0.0);
    
  }
  public Rectangle2D(double x,double y,double w,double h){
   this.xpos=x;
   this.ypos=y;
   this.width=w;
   this.height=h;
  }
  //get method
  public double getXpos(){//getXpos
    return xpos;
    }
  public double getYpos(){//getYpos
    return ypos;
    }
  public double getWidth(){//getWidth
    return width;
    }
  public double getHeight(){//getHeight
    return height;
    }
  //set method
  public void setXpos(double x){//setXpos
    xpos=x;
  }
  public void setYpos(double y){//setYpos
    ypos=y;
  }
  public void setWidth(double w){//setWidth
    width=w;
  }
  public void setHeight(double h){//setHeight
    height=h;
  }
  //other method
  public double getArea(){//getArea
    return width*height;
  } 
  public double getPerimeter(){//getPerimeter
    return 2*(width+height);
  }
  public boolean contains(double x,double y){//determine if the point is inside the rectangle

  return xpos<x&&x<(width+xpos)&&ypos<y&&y<(height+ypos);
  
  }
  public boolean contains(Rectangle2D r){//determine if the rectangle is inside the rectangle
    return xpos<=r.xpos&&ypos<=r.ypos&&(xpos+width)>=(r.xpos+r.width)&&(ypos+height)>=(r.ypos+r.height);
    
  }
}//end class