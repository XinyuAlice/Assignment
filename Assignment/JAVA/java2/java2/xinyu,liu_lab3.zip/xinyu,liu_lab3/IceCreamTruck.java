/*CSCI1101-Lab3-exercise2
the program is to track the number of ice-creams sold by each of the trucks and the total number of ice-creams sold by all the trucks 
<Xinyu,Liu><B00783546><2018.2.2>*/
public class IceCreamTruck {

    //attributes
    public static double price;
    public static int trucknumber;
    public int numberofIcecream;
    public static int totalNumber;
    public int truckID;

    //constructor
    IceCreamTruck(int ID) {
        truckID=ID;
        
        trucknumber++;
        numberofIcecream = 0;
    }

    public void sale() {//Sale
        numberofIcecream++;
        totalNumber++;

    }

    public String toString() {//toString
        String r = "";
        r += "Ice-creams sold by truck:" + numberofIcecream + "\n";
        r += "Total Sales for truck:" + price * numberofIcecream + "\n";
        return r;
    }

    public static double setPrice(double p) {//setPrice
        price = p;
        return price;
    }

    public static int totalNumber() {//totalNumber
        return totalNumber;
    }

    public static double averageSale() {//averageSale
        return totalNumber / trucknumber;
    }

    public static double totalSale() {//totalSale
        return price * totalNumber;
    }
}
