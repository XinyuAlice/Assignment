/*CSCI1101-Lab3-exercise2demo
the program is the demo of IcecreamTruck 
<Xinyu,Liu><B00783546><2018.2.2>*/
public class IcecreamTruckDemo {
    public static void main(String[]args){
       //create truck
       IceCreamTruck t1=new IceCreamTruck(1);
       IceCreamTruck t2=new IceCreamTruck(2);
       IceCreamTruck t3=new IceCreamTruck(3);
       IceCreamTruck t4=new IceCreamTruck(4);
      
       IceCreamTruck.price= 5;
       t1.sale();
       t1.sale();
       t1.sale();
       t2.sale();
       t2.sale();
       t2.sale();
       t3.sale();
       t3.sale();
       t4.sale();
       t4.sale();
       System.out.print("Ice-cream Sales by Truck: ");//print Ice-cream Sale by truck
       System.out.println("Ice-creams sold by truck1:"+t1.numberofIcecream);//truck1
       System.out.print("Total Sales for truck1:"+t1.numberofIcecream*IceCreamTruck.price);
       System.out.println("Ice-creams sold by truck2:"+t2.numberofIcecream);//truck2
       System.out.print("Total Sales for truck2:"+t2.numberofIcecream*IceCreamTruck.price);      
       System.out.println("Ice-creams sold by truck3:"+t3.numberofIcecream);//truck3
       System.out.print("Total Sales for truck3:"+t3.numberofIcecream*IceCreamTruck.price);     
       System.out.println("Ice-creams sold by truck4:"+t4.numberofIcecream);//truck4
       System.out.print("Total Sales for truck4:"+t4.numberofIcecream*IceCreamTruck.price); 
       
       System.out.println("Total Ice-cream sold by all trucks:"+IceCreamTruck.totalNumber);//totalsold
       System.out.println("Total sales:"+IceCreamTruck.totalSale());//totalSales
       System.out.println("Average sales per truck:"+IceCreamTruck.totalSale()/IceCreamTruck.trucknumber);//aveargeSal
    }
}
