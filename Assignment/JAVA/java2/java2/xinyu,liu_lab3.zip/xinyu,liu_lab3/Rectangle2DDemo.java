/*CSCI1101-Lab3-exercise1demo
the program is the demo of Rectangle2D
<Xinyu,Liu><B00783546><2018.2.2>*/
public class Rectangle2DDemo {
    public static void main(String[]args){
  Rectangle2D r1= new Rectangle2D(2, 2, 5.5 , 4.9);
  // Display results
		
		System.out.println("Area of r1: " + r1.getArea());//print Area of r1
		System.out.println("Perimeter of r1: " + r1.getPerimeter());//print perimeter of r1 
                System.out.println(r1.contains(3, 3)); //determine if r1 contains(3,3)
                System.out.println(r1.contains(new Rectangle2D(4, 5, 10.5, 3.2)));//determine if r1 contains new Rectangle
  Rectangle2D r2= new Rectangle2D(2.7, 3.2, 5 , 4.3);  
               
		System.out.println("Area of r2: " + r2.getArea());//print Area of r2
		System.out.println("Perimeter of r2: " + r2.getPerimeter());//print perimeter of r2
                System.out.println(r2.contains(2, 4)); //determine if r1 contains(2,4)

                System.out.println(r2.contains(new Rectangle2D(3, 6, 8.5, 7)));//determine if r2 contains new Rectangle
  Rectangle2D r3= new Rectangle2D(4.7, 6.3, 5 , 5.3);  
                
		System.out.println("Area of r3: " + r3.getArea());//print Area of r3
		System.out.println("Perimeter of r3: " + r3.getPerimeter());//print perimeter of r3
                System.out.println(r3.contains(4, 3)); //determine if r1 contains(4,3)

                System.out.println(r3.contains(new Rectangle2D(3.5, 1.7, 5, 6.6)));//determine if r3 contains new Rectangle             
				
		
	}//end main method
}//end class