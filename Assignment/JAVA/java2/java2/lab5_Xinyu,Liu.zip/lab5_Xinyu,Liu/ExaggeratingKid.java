/*CSCI1101-Lab5-exercise2
the program is the aggregation from SchoolKid
<Xinyu,Liu><B00783546><2018.2.27>*/
public class ExaggeratingKid extends Schoolkid {
    //attributes
    public String childGreeting;
    //constructor
    public ExaggeratingKid(){
        
    }
    public ExaggeratingKid(String c,int a,String t,String g,String cg){
        super(c,a,t,g);
        childGreeting=cg;
    }
    //get method(accessor)
    public int getAge(){
        return age+2;
    }
    public String getGreeting(){
        childGreeting="I am the best";
        return childGreeting;
    }
    //set method(mutator)
    public void setAge(int n){
        age=n;
        
    }
    public void setGreeting(String g){
        childGreeting=g;
    }
    //toString
    public String toString(){
        String r="";
        r+=super.toString();
        r+="The child's greeting is "+ childGreeting;
        return r;
    }
}
