/*CSCI1101-Lab5-exercise2
the program is the demo of ExaggeratingKid
<Xinyu,Liu><B00783546><2018.2.27>*/
public class ExaggeratingKidDemo {
    public static void main(String[]args){
        
        ExaggeratingKid C=new ExaggeratingKid("Clarence",6,"Ann","See you tomorrow","I am the best");
        
        
        System.out.println("The child is "+C.getAge()+"yeas old");
        System.out.println("The child's greeting is "+C.getGreeting());
        System.out.println(C.toString());
    }//end main method
}//end class
