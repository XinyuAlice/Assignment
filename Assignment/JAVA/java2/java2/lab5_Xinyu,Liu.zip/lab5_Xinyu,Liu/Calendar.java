/*CSCI1101-Lab5-exercise3
the program is a calendar which uses a 2-d array
<Xinyu,Liu><B00783546><2018.2.27>*/
import java.util.Scanner;

public class Calendar {

    public static void main(String[] args) {
        Scanner kb = new Scanner(System.in);
        String month, first;
        int day, place = 0, counter = 1;
        int i, j;
        System.out.println("Enter the month:");//input month
        month = kb.next();
        System.out.println("What day is the first day of the month:");//input the start day
        first = kb.next();
        System.out.println("How many days in this month:");//input days
        day = kb.nextInt();
        System.out.println(month);//print the month
        System.out.println("Sun      Mon      Tue      Wed     Thu      Fri     Sat");//print the first line of the calendar
        String[][] a = new String[6][7];//set up a 2-d array
        for (i = 0; i < 6; i++) {
            for (j = 0; j <7; j++) {
                a[i][j] = "";
            }
        }
            //use if statement to determine which day is the start day
            if ("Sunday".equals(first)) {
                place = 0;
            }
            if ("Monday".equals(first)) {
                place = 1;
            }
            if ("Tuesday".equals(first)) {
                place = 2;
            }
            if ("Wednesday".equals(first)) {
                place = 3;
            }
            if ("Thusday".equals(first)) {
                place = 4;
            }
            if ("Friday".equals(first)) {
                place = 5;
            }
            if ("Saturday".equals(first)) {
                place = 6;
            }
            //decide the second line of the calendar:from which day the calendar will begin
            for (i = place; i < 7; i++) {
                a[0][i] = Integer.toString(counter);//col
                counter++;//increase counter each time
            }
            
            while (counter <= day) {//when counter>the days of the month,the loop will end
            for (i = 1; i < 6; i++) {
                for (j = 0; j < 7; j++) {
                    a[i][j] = Integer.toString(counter);
                    if (counter <= day) {
                        counter++;
                    } else {
                        a[i][j] = "";
                    }
                }

            }
            
            for (i = 0; i < 6; i++) {//row 
                String[] calendar = a[i];
                for (j = 0; j < 7; j++) {//col
                    System.out.print(calendar[j] + "\t\t\t");
                }
                System.out.println();
            }

        }
    }
}
