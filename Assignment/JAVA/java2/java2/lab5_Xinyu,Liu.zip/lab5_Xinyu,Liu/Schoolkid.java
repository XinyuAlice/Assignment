/*CSCI1101-Lab5-exercise2
the program is the base class for children at school
<Xinyu,Liu><B00783546><2018.2.27>*/
public class Schoolkid {
    //attributes
    public String childName;
    public int age;
    public String teacherName;
    public String greeting;
    //constructor
    public Schoolkid() {//no args
        
    }
   public Schoolkid(String c,int a,String t,String g){//with parameters
        childName=c;
        age=a;
        teacherName=t;
        greeting=g;
    }
    //get methods(accessor)
    public int getAge(){
        return age;
    }
    public String getChildName(){
        return childName;
    }
    public String getTeacherName(){
        return teacherName;
    }
    public String getGreeting(){
        return greeting;
    }
    //set methods(mutator)
    public void setAge(int a){
        age=a;
    }
    public void setChildName(String c){
        childName=c;
    }
     public void setTeacherName(String t){
        teacherName=t;
    }
      public void setGreeting(String g){
        greeting=g;
    }
    //toString method
      public String toString(){
          String c="";
          c+=childName+" is a " + age+" yeas old kid"+"\n"+"He sends a greeting to his teacher "+teacherName+"\n"+"The greeting is:"+greeting+"\n";
      return c;
    }
}
