/*CSCI1101-Lab5-exercise1
the program is about the book and the number page of that
<Xinyu,Liu><B00783546><2018.2.27>*/
public class Book {
    //attributes
    public int numPages;
    //constructor
    public Book(){//no args
        
    }
    public Book(int n){//with parameter
        numPages=n;
    }
    //get method(accessor)
    public int getPages(){
        return numPages;
    }
    //set method(mutator)
    public void setPages(int p){
        numPages=p;
    }
    //toString method
    public String toString(){
        String c="";
        c+="The page is"+numPages+"\n";
        return c;
    }
    
}
