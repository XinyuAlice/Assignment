/*CSCI1101-Lab5-exercise1
the program is the demo of Dictionary
<Xinyu,Liu><B00783546><2018.2.27>*/
public class DictionaryDemo {
    public static void main(String[]args){
    Dictionary A=new Dictionary(4,8);//set the dictionary
    A.setDefinitions(8);
    A.setPages(4);
    A.computerRatio();
    System.out.println(A.toString());
    }//end main method
}//end class
