/*CSCI1101-Lab5-exercise1
the program is the aggregation from the Book
<Xinyu,Liu><B00783546><2018.2.27>*/
public class Dictionary extends Book {
    //attributes
    public int numDefinition;
    //constructor
    public Dictionary(int p, int d) {
        numPages = p;
        numDefinition = d;
    }
    //set method(mutator)
    public void setDefinitions(int n) {
        numDefinition = n;
    }
    //get method(accessor)
    public int getDefinition() {
        return numDefinition;
    }
    //computerRatio method 
    public int computerRatio() {
        return numDefinition / numPages;
    }
    //toString
    public String toString() {
        String r = "";
        r += super.toString();
        r += "The number of the definition:" + numDefinition + "\n";
        r += "The computerRatio is" + numDefinition / numPages + "\n";
        return r;
    }
}


