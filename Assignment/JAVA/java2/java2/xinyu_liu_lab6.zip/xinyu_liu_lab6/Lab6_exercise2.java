/*CSCI1101-lab6-exercise1
the program is to read words into an ArrayList list1 and creates another ArrayList list2 that has the same words in list1 but no duplicates.
<Xinyu,Liu><B00783546><2018.3.7>*/
import java.util.Scanner;
import java.util.ArrayList;
public class Lab6_exercise2 {

    public static void main(String[] args) {
        ArrayList<String> list1 = new ArrayList<String>();//create the Arraylist1
        ArrayList<String> list2 = new ArrayList<String>();//create the Arraylist2
        Scanner kb=new Scanner(System.in);
        System.out.println("Enter words on one line, end with -1");
        String a=kb.next();//input elements to Arraylist1
        while (!a.equals("-1")) {
            list1.add(a);
            a=kb.next();
        }
        for(int i=0;i<list1.size();i++){//initialize i,test i,update i
            a=list1.get(i);
            if(list2.contains(a)){
                list2.remove(a);// to remove the repeated elements
            }
                list2.add(a);
        }
        System.out.println("Array List with no duplicates: ");
        System.out.println(list2);//print all the elements in list2
        
    }
}
