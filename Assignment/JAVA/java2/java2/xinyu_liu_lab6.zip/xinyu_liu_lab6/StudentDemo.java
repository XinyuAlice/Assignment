/*CSCI1101-lab6-exercise3demo
the program is the demo of student and read names from A to Z 
<Xinyu,Liu><B00783546><2018.3.7>*/
import java.util.Scanner;
import java.util.ArrayList;


public class StudentDemo {
   public static void Sort(ArrayList<String>student){//sort
       String temp;
       if(student.size()>1){
           for(int i=0;i<student.size();i++){
               for(int j=0;j<student.size()-j;j++){
                   if(student.get(j).compareTo(student.get(j+1))>0){
                       temp=student.get(j);
                       student.set(j,student.get(j+1));
                       student.set(j+1, temp);
                   }
               }
           }
       }
   }
    public static void main(String[] args) {
        Scanner kb = new Scanner(System.in);
        ArrayList<String> student = new ArrayList<String>();
        ArrayList<Student> list = new ArrayList<Student>();

        String name;
        double gpa;

        System.out.println("Enter student name or quit: ");//input name
        name = kb.next();

        //add student to the arraylist until enter quit and then print it out
        while (!name.equals("quit")) {
            System.out.println("Enter grade point ave: ");//input gpa
            gpa = kb.nextDouble();

            Student s = new Student(name, gpa);

            s.setName(name);
            s.setGradePointAverage(gpa);
            student.add(s.toString());
            list.add(new Student(name, gpa));

            System.out.println("Enter student name or quit: ");
            name = kb.next();
        }

        StudentDemo d=new StudentDemo();
        d.Sort(student);//call the sort
         
        System.out.println("Students: \n" + student);
        Student student1=new Student("",0.0);
        for(int i=0;i<list.size();i++){
            for(int j=1;j<list.size()-i;j++){
                if(list.get(j).getGradePointAverage()>list.get(j-1).getGradePointAverage()){
                    student1=list.get(j-1);
                    list.set(j-1,list.get(j));
                    list.set(j, student1);
                }
            }
        }
        System.out.println("Students in order of Grade Point Average: \n" +list);

    }

   
    }

