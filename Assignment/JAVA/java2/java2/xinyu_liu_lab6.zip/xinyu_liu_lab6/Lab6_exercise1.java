/*CSCI1101-lab6-exercise1
the program is to read words into two ArrayLists list1 and list2 and then creates a third ArrayList that contains words which are common to both list1 and list2. 
<Xinyu,Liu><B00783546><2018.3.7>*/
import java.util.Scanner;
import java.util.ArrayList;

public class Lab6_exercise1 {

    public static void main(String[] args) {
        ArrayList<String> list1 = new ArrayList<String>();//create the Arraylist1
        ArrayList<String> list2 = new ArrayList<String>();//create the Arraylist2
        ArrayList<String> list3 = new ArrayList<String>();//create the Arraylist3 that contains the elements both in
        System.out.println("Enter words on one line,end with -1");
        Scanner kb = new Scanner(System.in);
        String a = kb.next();
        while (!a.equals("-1")) {//when the input is not -1,add input to list1 
            list1.add(a);
            a=kb.next();
        }
        System.out.println("Enter words on one line,end with -1");
        String b = kb.next();
        while (!b.equals("-1")) {//when the input is not -1,add input to list2
            list2.add(b);
            b=kb.next();
        }
        System.out.println(list1);//print all the element of list1

        System.out.println(list2);//print all the element of list2
        System.out.println("Array List with common strings: ");
        for(int i=0;i<list1.size();i++){//initialize i,test i,update i,
            a=list1.get(i);
            if(list2.contains(a)){
                if(list3.contains(a)){
                list3.remove(a);
            }
                list3.add(a);
        }
        }
            System.out.println(list3);
        }
    }
        

       
