/*CSCI1101-lab6-exercise3
the program is to create student and use name and gpa as attributes
<Xinyu,Liu><B00783546><2018.3.7>*/
public class Student {
    //attributes
    public String name;
    public double gradePointAverage;
    //constructor
    public Student(){//no args
    
    }
    
    public Student(String n,double gpa){//with parameters
        name=n;
        gradePointAverage=gpa;
    }
    //get method 
    public String getName(){
        return name;
    }
    public double getGradePointAverage(){
     return gradePointAverage;
    
    }
    //set method 
    public void setName(String n){
        name=n;
    }
    public void setGradePointAverage(double gpa){
        gradePointAverage=gpa;
    }
    //toString method
    public String toString(){
        String r=name + " Grade Point Ave: "+ gradePointAverage;
        return r;
    }
    

}
