/*CSCI1101-lab7-exercise
the program is the demo for the linklist
<Xinyu,Liu><B00783546><2018.3.13>*/
public class LinkListDemo {
    public static void main(String[] args) { 
      LinkedList myList = new LinkedList();//create a linklist
      myList.add(0,"T"); 
      myList.add(1,"A"); 
      myList.add(2,"T");
      myList.add(3,"N");
      
      myList.printEvenIndex();
      myList.printAllNodesWith("T");
      myList.addAsSecondNode("C");
      System.out.print("\n");
      myList.enumerate();
   }//end main
}//end class
