/*CSCI1101-lab7-exercise
the program is the node class for the linklist
<Xinyu,Liu><B00783546><2018.3.13>*/
public class Node {
   //attributes
   public String data;
   public Node next;
   //constructor
   public Node(String d, Node n){ 
      data = d; 
      next = n; 
   } 
   //get Method
   public String getData(){ return data;} 

   public Node getNext(){ return next;}
   //set method
   public void setData(String d){ data = d;}
   public void setNext(Node n){ next = n; } 

   //String method
   public String toString(){ 
      return data + "-->"; 
  } 
} 

