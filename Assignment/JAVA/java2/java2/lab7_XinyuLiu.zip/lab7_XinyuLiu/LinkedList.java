/*CSCI1101-lab7-exercise
the program is the linklist class
<Xinyu,Liu><B00783546><2018.3.7>*/
public class LinkedList {
    //attributes
    public Node front;
    public int count;
    //constructor 

    public LinkedList() {
        front = null;
        count = 0;
    }
   //add a node to the front of the linked list 
    public void addToFront(String d) {
        Node n;
        n = new Node(d, front);
        front = n;
        count++;
    }

    //get the current size of the list 
    public int size() {
        return count;
    }
    //check if the list is empty 

    public boolean isEmpty() {
        return (count == 0);
    }
    //clear the list 

    public void clear() {
        front = null;
        count = 0;
    }

    //get the content of the first node 
    public String getFrontData() {
        if (front == null) {
            return "Empty list";
        } else {
            return front.getData();
        }
    }
    //new method added - get the first node 

    public Node getFront() {
        return front;
    }

    //scan the list and print contents 
    public void enumerate() {
        Node curr = front;
        while (curr != null) {
            System.out.print(curr);
            curr = curr.getNext();
        }
        System.out.println(".");
    }
    //add content to the list
    public void add(int index, String d) {
        if (index < 0 || index > size()) {

            System.out.print("Can't add-index out of bounds");
        } else {

            if (index == 0) {
                addToFront(d);
            } else {
                Node curr = front;
                for (int i = 0; i < index - 1; i++) {
                    curr = curr.getNext();
                }
                Node n = new Node(d, curr.getNext());
                curr.setNext(n);
                count++;
            }
        }
    }
    //print the contents of all the nodes with even indices
    public void printEvenIndex() {
        Node curr = front;

        if (front == null) {

            System.out.print("Cannot print-empty list");
        } else if (front != null) {
            for (int i = 0; i < size(); i++) {

                if (i % 2 == 0) {

                    System.out.print(curr.getData() + "-->");

                }
                curr = curr.getNext();
            }

        }
    }
    //print the indices of all the nodes that have the String d in them
    public void printAllNodesWith(String d) {
        Node curr = front;
        System.out.print("\n");

        if (front != null) {
            for (int i = 0; i < size(); i++) {
                if (curr.getData().equals(d)) {
                    System.out.print(i);
                }
                curr = curr.getNext();
            }
        } else {
            System.out.println("Cannot find");

        }

    }
    //add a new Node to the linked list with String d as the second node in the list
    public void addAsSecondNode(String d) {
         
         
        if (front == null) {
            addToFront(d);
        } else if (front != null) {
            Node curr = front;
            Node n=new Node(d,curr.getNext());
            curr.setNext(n);
            
        }
          count++;
    }

}
