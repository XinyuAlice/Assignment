/*CSCI1101-Lab2-exercise1Demo
the program is the demo of the rectangle
<Xinyu,Liu><B00783546><2018.1.23>*/
//RectangleDemo.java
import java.util.Scanner;
  public class RectangleDemo{
  
   public static void main(String[]args){
      int length;
      int width;
      Scanner kb=new Scanner(System.in);
      System.out.print("Enter length and width:");//input length and width
      length=kb.nextInt();
      width=kb.nextInt();
      Rectangle rect1 ;
      rect1=new Rectangle(length,width);
      rect1.setLength(length);//set length
      rect1.setWidth(width);//set width

      System.out.println("Length:"+length);//toString 
      System.out.println("Width:"+width);//toString
      System.out.println("Area:"+rect1.findArea());//findArea
   }
  }
  

