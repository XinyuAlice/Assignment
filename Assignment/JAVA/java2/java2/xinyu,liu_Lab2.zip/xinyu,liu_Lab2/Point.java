/*CSCI1101-Lab2-exercise3
the program is to determine the points and compare them
<Xinyu,Liu><B00783546><2018.1.23>*/
//Point.java
public class Point {
    //attributes
    public int x;
    public int y;
    
    //constructor
    public Point(int x, int y) {
        this.x = x;
        this.y = y;
    }
    //get methods
    public int getX() {
        return x;
    }
    public int getY() {
        return y;
    }
    //set methods
    public void setX(int x) {
        this.x = x;
    }

    public void setY(int y) {
        this.y = y;
    }
    //equal  method
    public boolean equals(Point B){
        if(x==B.x&&y==B.y){
            return true;
        }
        else{
            return false;
        }   
    }
    //isHigher method 
    public boolean isHigher(Point B){
        if(y>B.y){//compare the y
            return true;
        }
        else{
            return false;
        }
    }
    //findLength method 
    public double findLength(Point B){
        double  length;
        length=Math.sqrt((x-B.x)*(x-B.x)+(y-B.y)*(y-B.y));//caculate the distance of the point 
        return length;
    }
    
}  