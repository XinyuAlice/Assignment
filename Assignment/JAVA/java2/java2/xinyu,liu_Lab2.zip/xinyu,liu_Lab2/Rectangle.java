/*CSCI1101-Lab2-exercise1
the program is to determine a rectangle
<Xinyu,Liu><B00783546><2018.1.23>*/
//Rectangle.java
public class Rectangle{
   //attributes
	private int length;
	private int width;
	//constructor
	public Rectangle(){//create a rectangle object with no data
   }
   public Rectangle(int l,int w){//create a rectangle object with data 
   length=l;
   width=w;
   }
   //set method
	public void setLength(int l){//setLength
		this.length = l;
	}
	public void setWidth(int w){//setWidth
		this.width = w;
	}
   //get method
	public int getLength(){//getLength
		return length;
	}
	public int getWidth(){//getWidth
		return width;
	}
   //findaArea
	public int findArea(){
		return length*width;
	}
   public String toString(){
      String r="";
      r+="Length:"+length+"\n";
      r+="Width:"+width+"\n";
      return r;
   }
}//end class
