/*CSCI1101-Lab2-exercise2
the program is to list the information of the stock and caculate its value and compare
<Xinyu,Liu><B00783546><2018.1.23>*/
//Stock.java
public class Stock{
  //attributes
  public String symbol;
  public double price;
  public int  shares;
  public double value=price*shares;

  //constructor
  public Stock(String sym,double prc,int sh){
  symbol=sym;
  price=prc;
  shares=sh;
  }
  //get methods
  public String getSymbol(){
   return symbol;
  }
  public double getPrice(){
   return price;
  }
  public int getShares(){
   return shares;
  }
  //set methods
  public void setSymbol(String sym){
   symbol=sym;
  }
  public void setPrice(double prc){
   price=prc;
  }
  public void setShares(int sh){
   shares=sh;
  }
  //toString method
  public String toString(){
   String r="";
   r+="Symbol:"+symbol+"\n";
   r+="Price"+price+"\n";
   r+="Number of shares"+shares+"\n";
   return r;
   }
   //compare method
   public int compare(Stock s){
     int result=0;          
    if(price*shares>s.price*s.shares){//value>s.value
     result=1;
     }
    
    if(price*shares==s.price*s.shares){//value==s.value
    
     result=0;
     }
   
    if(price*shares<s.price*s.shares){//value<s.value
    result=-1;
    }
    return result;
   
   
   }//end compare
  }//end class



 