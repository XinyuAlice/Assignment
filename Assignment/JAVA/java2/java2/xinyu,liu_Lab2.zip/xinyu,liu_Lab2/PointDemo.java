/*CSCI1101-Lab2-exercise3Demo
the program is the demo of point
<Xinyu,Liu><B00783546><2018.1.23>*/
//PointDemo.java
import java.util.Scanner;

public class PointDemo {

    public static void main(String args[]) {
        Point p1 = new Point(0, 0);
        Point p2 = new Point(0, 0);
        Point p3 = new Point(0, 0);
        Point p4 = new Point(0, 0);
        Point max = new Point(0, 0);
        Point max2 = new Point(0, 0);
        Scanner KB = new Scanner(System.in);
        System.out.println("Enter the x and y coordinates for point1: ");//input x,y of point1
        p1.x = KB.nextInt();
        p1.y = KB.nextInt();
        System.out.println("Enter the x and y coordinates for point2: ");//input x,y of point2
        p2.x = KB.nextInt();
        p2.y = KB.nextInt();
        System.out.println("Enter the x and y coordinates for point3: ");//input x,y of point3
        p3.x = KB.nextInt();
        p3.y = KB.nextInt();
        System.out.println("Enter the x and y coordinates for point4: ");//input x,y of point4
        p4.x = KB.nextInt();
        p4.y = KB.nextInt();
        //use the  isHigher to compare p1 and p2
        if (p1.isHigher(p2) == true) {
            max.x = p1.x;
            max.y = p1.y;
        } else {
            max.x = p2.x;
            max.y = p2.y;
        }
        //use the isHigher to compare p3 and p4

        if (p3.isHigher(p4) == true) {
            max2.x = p3.x;
            max2.y = p3.y;
        } else {
            max2.x = p4.x;
            max2.y = p4.y;

        }
        ////use the isHigher to compare p1 and p2

        if (max.isHigher(max2) == true) {
            System.out.println("[" + max.x + "," + max.y + "] is the highest point");
        } else {
            System.out.println("[" + max2.x + "," + max2.y + "] is the highest point");
        }
    
        //use findLengthh
        double l1=p1.findLength(p2);
        double l2=p3.findLength(p4);
        System.out.println("The Length between ["+p1.x+","+p1.y+"] and  ["+p2.x+","+p2.y+"] is "+l1);
        System.out.println("The Length between ["+p3.x+","+p3.y+"] and  ["+p4.x+","+p4.y+"] is "+l2);
        if(l1>l2){//compare length between p1 and p2 and length between p3 and p4
            System.out.println("Line from ["+p1.x+","+p1.y+"] to ["+p2.x+","+p2.y+"] is longer");
        }
        else
        {
           System.out.println("Line from ["+p3.x+","+p3.y+"] to ["+p4.x+","+p4.y+"] is longer"); 
        }

   }//end method
 }//end class

