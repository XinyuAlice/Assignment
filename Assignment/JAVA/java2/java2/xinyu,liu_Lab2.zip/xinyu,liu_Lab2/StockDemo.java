/*CSCI1101-Lab2-exercise2demo
the program is the demo of Stock:to caculate the value of the stock that user owns  
<Xinyu,Liu><B00783546><2018.1.23>*/
//StockDemo.java
import java.util.Scanner;
public class StockDemo
{
	public static void main(String[] args)
	{
	   Scanner keyboard = new Scanner(System.in);
		String sym1, sym2;
		double prc1, prc2;
		int sh1, sh2;
		//get the values for two stocks
		System.out.print("Enter the symbols for the two stocks: ");//input  symbols of the two stock
		sym1 = keyboard.next();
		sym2 = keyboard.next();
      System.out.print("Enter their prices: ");//input the price
		prc1 = keyboard.nextDouble();
		prc2 = keyboard.nextDouble();
		System.out.print("Enter the number of shares for the two stocks: ");//input the number of shares for the two stock
		sh1 = keyboard.nextInt();
		sh2 = keyboard.nextInt();
		
		//create the first Stock
		Stock s1 = new Stock(sym1,prc1,sh1);
		
		
		//create the second Stock
		Stock s2 = new Stock(sym2,prc2,sh2);
      
      System.out.println("I have the following stocks:");
      //toString method to print all
      System.out.println("Stock:"+s1.symbol);
      System.out.println("Price:"+prc1);
      System.out.println("Shares:"+sh1);
      System.out.println("Stock:"+sym2);
      System.out.println("Price:"+prc2);
      System.out.println("Shares:"+sh2);
      
      //compare method
      int n=s1.compare(s2);
      if(n==-1)
      System.out.printf(sym2+" is higher than"+sym1+" by "+"%.2f",(s2.shares*s2.price-s1.price*s1.shares));
      else if(n==0)
      System.out.printf(sym2+ " is equal to"+sym1);
      else
      System.out.printf(sym2+" is lower than "+sym1+" by "+"%.2f",(s1.shares*s1.price-s2.price*s2.shares));
      
      System.out.println("\n");
      
      System.out.println("The total value of my portfolio is $"+(s2.shares*s2.price+s1.price*s1.shares)); //print total value
      
      
   }
   }

   
   



     
		
