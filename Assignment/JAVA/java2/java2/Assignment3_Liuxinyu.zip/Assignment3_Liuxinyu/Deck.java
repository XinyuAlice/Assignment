/*CSCI1101-Assignment3-Deck
the program is the deck class,for the shuffle and transfer card
<Xinyu,Liu><B00783546><2018.3.16>*/
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
public class Deck {
    //create a arraylist
    public ArrayList<Card> cardDeck;
    //constructor
    public Deck() {

        cardDeck = new ArrayList<>(52);
    }
    //display
    public void display() {
    	Card temp=new Card(0, 0);
    	int i=1;
    	while(!cardDeck.isEmpty()){
    		temp=cardDeck.remove(0);
    		System.out.println(i+":"+temp.toString());
    		i++;
    	}
	}
    //tranbsfer card
    public Card Transfer(int n){//0-12:Diamond;13-25:Clubs;26-38:Hearts;39-51:Spades
    	Card temp = new Card(0, 0);
    	int domain = 4;
    	if(0<=n&&n<=13){
    		domain=0;
    	}else if(13<=n&&n<=25){
    		domain=1;
    	}else if(26<=n&&n<=38){
			domain=2;
		}else if(39<=n&&n<=51){
			domain=3;
		}else {
			System.out.println("n doesn't belong to 0-53!Interruption");
    		System.exit(0);
		}
    	switch (domain) {
		case 0:
			temp.setRank(n+1);
			temp.setSuit(0);
			break;
		case 1:
			temp.setRank(n+1-13);
			temp.setSuit(1);
			break;
		case 2:
			temp.setRank(n+1-26);
			temp.setSuit(2);
			break;
		case 3:	
			temp.setRank(n+1-39);
			temp.setSuit(3);
			break;
		default:
			System.out.println("invalid domain!Interruption");
			System.exit(0);
			break;
		}
		return temp;
    }


    //shuffle card
    public  void shuffle() {
    	ArrayList<Card> temp = new ArrayList<>();
    	Card c=new Card(0, 0);
        List numlist = new ArrayList();  //save numbers
        Random rd = new Random();
        while(numlist.size()<52){
            int num = rd.nextInt(52);//random number (- [0,52)
            if(!numlist.contains(num)) {  
            	numlist.add(num);  //add
            	c=Transfer(num);
            	temp.add(c);
            }
        }
        cardDeck=temp;
    }

}