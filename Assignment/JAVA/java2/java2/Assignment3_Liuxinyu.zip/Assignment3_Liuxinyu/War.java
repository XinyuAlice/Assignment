/*CSCI1101-Assignment3-War
the program is the War class for setting the rules for the war game
<Xinyu,Liu><B00783546><2018.3.16>*/
import java.util.*;

public class War {

    public void rock() {
        Scanner kb = new Scanner(System.in);
        String name1, name2;
        System.out.println();
        System.out.println("Welcome to WAR! Let's Play!");
        System.out.println("Enter the first player's name: ");
        name1 = kb.next();
        System.out.println("Enter the second player's name: ");
        name2 = kb.next();
        Deck deck = new Deck();
        deck.shuffle();

        LinkedList<Card> deck1 = new LinkedList<>();
        LinkedList<Card> deck2 = new LinkedList<>();
        deck1.addAll(deck.cardDeck.subList(0, 26));              //26 cards for p1       
        deck2.addAll(deck.cardDeck.subList(26, deck.cardDeck.size()));//26 cards for p2

        while (true) {
            Card p1Card = deck1.pop();  //each player place one card face up
            Card p2Card = deck2.pop();

            //display the  card
            System.out.printf("%-10s %10s %10s %10s %10s\n", name1, "#Cards", name2, "#Cards", "Winner");

            //rank comparation between two cards
            if (p1Card.getCard() > p2Card.getCard()) {//if player 1 win 
                deck1.addLast(p1Card);  //higher rank wins both cards and 
                deck1.addLast(p2Card);  //places them at the bottom of his deck.
                System.out.printf("%-10s %10d %10s %10d %10s\n", p1Card.toString(), deck1.size(), p2Card.toString(), deck2.size(), name1);
            }//end if
            else if (p1Card.getCard() < p2Card.getCard()) {//if player 2 win 
                deck2.addLast(p1Card);
                deck2.addLast(p2Card);
                System.out.printf("%-10s %10d %10s %10d %10s\n", p1Card.toString(), deck1.size(), p2Card.toString(), deck2.size(), name2);
            }//end else if
            else { //war happens when both cards' rank matched
                //if either do not have 4 cards to begin war
                if (deck1.size() < 3) {
                    deck1.clear();

                    System.out.println(name2 + "Wins! Congratulations");
                    break;
                } else if (deck2.size() < 3) {
                    deck2.clear();

                    System.out.println(name1 + "Wins! Congratulations");
                    break;
                } else {
                    System.out.printf("%-10s %10s %10s %10s %10s\n", "********", "********", "WAR", "********", "********");

                    //creating war cards
                    List<Card> war1 = new ArrayList<>();
                    List<Card> war2 = new ArrayList<>();

                   
                    for (int i = 0; i < 4; i++) {
                        

                        war1.add(deck1.pop());  //place additional card for war
                        war2.add(deck2.pop());
                    }//end for
                    

                    if (war1.get(0).getCard() > war2.get(0).getCard()) {
                        deck1.addAll(war1); //player1 get all 10 cards
                        deck1.addAll(war2);
                        deck1.addLast(p1Card);   
                        deck1.addLast(p2Card);
                        System.out.printf("%-10s %10d %10s %10d %10s\n", war1.get(0).toString(), deck1.size(), war2.get(0).toString(), deck2.size(), name1);
                        System.out.printf("%-10s %10s %10s %10s %10s\n", "********", "********", "END WAR", "********", "********");
                    }//end if
                    //otherwise player 2 wins the war round
                    else {
                        deck2.addAll(war1); //player2 get all 10 cards
                        deck2.addAll(war2);
                        deck2.addLast(p1Card);  
                        deck2.addLast(p2Card);
                        System.out.printf("%-10s %10d %10s %10d %10s\n", war1.get(0).toString(), deck1.size(), war2.get(0).toString(), deck2.size(), name2);
                        System.out.printf("%-10s %10s %10s %10s %10s\n", "********", "********", "END WAR", "********", "********");
                    }
                   

                }

            }
        

        //game over either one player runs out of card(deck size is 0)
        if (deck1.isEmpty()) {
            System.out.println(name2 + "Wins! Congratulations");
            break;
        } else if (deck2.isEmpty()) {
            System.out.println(name1 + "Wins! Congratulations");
            break;
        }
    }//end while  
}
}