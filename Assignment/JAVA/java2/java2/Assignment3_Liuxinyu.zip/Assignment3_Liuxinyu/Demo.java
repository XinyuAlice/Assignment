/*CSCI1101-Assignment3-Demo
the program is the demo class for the war game
<Xinyu,Liu><B00783546><2018.3.16>*/
import java.util.*;
public class Demo {

	public static void main(String[] args) {
	
		War war=new War();
		war.rock();
        System.out.println("play again?(y or n)");
        String str;
        Scanner kb = new Scanner(System.in);
        str=kb.next();
        while(true){
        	if(str.equals("y")){
            	war.rock();
            }else if(str.equals("n")){
            	System.exit(0);
            }else{
    			System.out.println("invalid string,please reinput!");
    			str=kb.next();
    		}
        }    
	}
}
