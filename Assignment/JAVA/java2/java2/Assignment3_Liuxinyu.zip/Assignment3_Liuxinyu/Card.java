/*CSCI1101-Assignment3-Card
the program is the Card class for creating the suit and rank
<Xinyu,Liu><B00783546><2018.3.16>*/
public class Card {
   //attributes
    public int rank;
    public int suit;
    //constructor
    public Card(int rank, int suit) {
        this.rank = rank;
        this.suit = suit;

    } 
    //get method
    public int getCard() {
        return rank + suit;
    }

    public int getRank() {
        return rank;
    }

    public int getSuit() {
        return suit;
    }
    //set method
    public void setRank(int r) {
        rank = r;
    }

    public void setSuit(int s) {
        suit = s;
    }
    //String method
    public String toString() {
        String s = "";
        if (rank <= 10) {
            s += getRank() + "";
        } else if (rank == 11) {
            s += "Jack";
        } else if (rank == 12) {
            s += "Queen";
        } else if (rank == 13) {
            s += "King";
        } else if (rank == 14) {
            s += "Ace";
        }
        switch (suit) {//four suits:diamond,spades,clubs,hearts
            case 0:
                s += "Diamond";
                break;
            case 1:
                s += "Clubs";
                break;
            case 2:
                s += "Hearts";
                break;
            case 3:
                s += "Spades";
                break;
            default:
                break;
        }
        return s;
    }

}
