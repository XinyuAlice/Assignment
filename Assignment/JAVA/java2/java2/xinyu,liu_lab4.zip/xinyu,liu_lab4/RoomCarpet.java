/*CSCI1101-lab4-exercise1
the program is to aggregates the RoomCarpet class from RoomDimension
<Xinyu,Liu><B00783546><2018.2.8>*/
public class RoomCarpet {
    //attributes

    public double carpetCost;
    public double totalCost;
    RoomDimension room;
    //constructor
    RoomCarpet(RoomDimension r, double cost) {
        room = r;
        carpetCost = cost;
        totalCost = room.getLength() * room.getWidth ()* carpetCost;
    }
    //get method
      public double getCarpetCost() {
        return carpetCost;
    }
      
    //get TotalCost
    public double getTotalCost() {
        return totalCost;
    }
    //set method
    public void setCarpetCost(double c){
        carpetCost=c;
    }
    //set TotalCost
    public void setTotalCost() {
        totalCost= room.getWidth()* getCarpetCost() * room.getLength () ;
    }
    
    //toString method
    public String toString() {
        String s = "";
        s += room.toString();
        s += "Carpet Cost ($per sq.ft): " + carpetCost + "\n";
        s += "Total cost ($):" + totalCost + "\n";
        return s;
    }
    //boolean method 
    public boolean costsMore(RoomCarpet other) {
        if (this.getTotalCost() > other.getTotalCost()) 
            return true;
        else 
            return false;
        
    }
}