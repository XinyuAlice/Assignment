/*CSCI1101-lab4-exercise1demo
the program is the demo of the RoomCarpet
<Xinyu,Liu><B00783546><2018.2.8>*/
import java.util.Scanner;

public class RoomCarpetDemo {

    public static void main(String[] args) {
        //attributes
        double l1, w1, l2, w2, c1, c2, tc1, tc2;

        Scanner kb = new Scanner(System.in);
        System.out.println("Enter the dimensions of the first room: ");//input dimension1:length and width
        l1 = kb.nextDouble();
        w1 = kb.nextDouble();
        System.out.println("Enter the cost per square foot of carpet: ");//input the cost 
        c1 = kb.nextDouble();
        System.out.println("Enter the dimensions of the second room:");//input dimension2:;ength and width
        l2 = kb.nextDouble();
        w2 = kb.nextDouble();
        System.out.println("Enter the cost per square foot of carpet:");//input the cost
        c2 = kb.nextDouble();
        RoomDimension r1 = new RoomDimension(l1, w1);
        RoomDimension r2 = new RoomDimension(l2, w2);

        RoomCarpet rc1 = new RoomCarpet(r1, c1);
        RoomCarpet rc2 = new RoomCarpet(r2, c2);
        r1.setLength(l1);
        r2.setLength(l2);
        r1.setWidth(w1);
        r2.setWidth(w2);

        rc1.setTotalCost();
        rc2.setTotalCost();
        //compare the total cost of the two rooms
        if (rc1.costsMore(rc2)) {

            System.out.println(rc1.toString());
            System.out.println("cost more than");
            System.out.println(rc2.toString());
        }

        if (rc2.costsMore(rc1)) {
            System.out.println(rc2.toString());
            System.out.println("cost more than");
            System.out.println(rc1.toString());
        } else 
            System.out.println(rc1.toString());
            System.out.println("and");
            System.out.println(rc2.toString());
            System.out.println("cost the same");
        
    }

}
