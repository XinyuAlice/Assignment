/*CSCI1101-lab4-exercise2
the program is to aggregates the circle from point 
<Xinyu,Liu><B00783546><2018.2.8>*/
public class Circle {
    //attributes
    public Point centerPoint;
    public double radius;
    //constructor
    public Circle(){
       this.radius=1.0;
       this.centerPoint=new Point(0,0);
    }
    public  Circle(Point c,double r ){
       
        centerPoint=c;
        radius=r;
    }
    //get method
    public double getArea(){
        return Math.PI*Math.pow(radius,2);
    }
    
    public double getPerimeter(){
        return Math.PI*radius*2;
    }
    //boolean method
    //cotain point method
    public boolean contains(Point p){
        if(centerPoint.distanceFrom(p)<radius)
            return true;
        else
            return false;
        
        
    }
    //touch method
    public boolean touches(Point p){
        if(centerPoint.distanceFrom(p)==radius)
            return true;
        else
            return false;
        
    }
    //contain circle method
    public boolean contains(Circle c){
        if(this.centerPoint.distanceFrom(c.centerPoint)<(this.radius-c.radius))
            return true;
        else
            return false;
    }
    
    
    
    
}