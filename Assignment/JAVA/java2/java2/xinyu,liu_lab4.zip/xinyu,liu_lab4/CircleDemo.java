/*CSCI1101-lab4-exercise2
the program is the demo of the circle
<Xinyu,Liu><B00783546><2018.2.8>*/
import java.util.Scanner;
public class CircleDemo {
    public static void main(String[]args){
        //attributes
        int x1,y1,x2,y2,x0,y0;
        double r1,r2;
       
        Scanner kb=new Scanner(System.in);
        System.out.println("Enter the center point of circle1: ");//input the first center point
        x1=kb.nextInt();
        y1=kb.nextInt();
        System.out.println("Enter the radius of circle1:");//input the radius
        r1=kb.nextDouble();
        System.out.println("Enter a point to determine if the point is inside the circle1:");//input the point
        x0=kb.nextInt();
        y0=kb.nextInt();
        System.out.println("Enter the center point of circle2: ");//input the second ceterpoint
        x2=kb.nextInt();
        y2=kb.nextInt();
        System.out.println("Enter the radius of circle2:");//input the radius
        r2=kb.nextDouble();
        Point p1=new Point(x1,y1);
        Point p0=new Point(x0,y0);
        Point p2=new Point(x2,y2);
        Circle c1 = new Circle(p1,r1);
        Circle c2=new Circle(p2,r2);
        //boolean if contain point
        boolean result1=c1.contains(p0);
        if(result1==true){
        System.out.println("Circle 1 contains the point");
        }
        if(result1==false){
        System.out.println("Circle 1 does not contain the point");
        }
        //boolean if touch the circle
        boolean result2=c1.touches(p0);
        if(result2==true){
        System.out.println("Point touches  Circle1");
        }
        if(result2==false){
        System.out.println("Point does not touch  Circle1");
        }
        //boolean if cotain the circle
        boolean result3=c1.contains(c2);
        if(result3==true){
        System.out.println("Circle 1 contains Circle2");
        }
        if(result3==false){
        System.out.println("Circle 1 does not contain Circle2");
        }
            
        
    }
    
}