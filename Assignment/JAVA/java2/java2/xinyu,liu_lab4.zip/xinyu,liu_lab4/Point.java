/*CSCI1101-lab4-exercise2
the program is to determine a point
<Xinyu,Liu><B00783546><2018.2.8>*/
public class Point {
    //attributes
    public int x;
    public int y;
    //constructor
    Point(int x, int y) {
        this.x = x;
        this.y = y;
    }
    //get method
    public double getX() {
        return x;
    }

    public double getY() {
        return y;
    }

    //set method 
    public void setX(int x1) {
        x = x1;

    }

    public void setY(int y1) {
        y = y1;
    }
    //distanceFrom method
    public double distanceFrom(Point another) {
        return Math.pow(Math.pow(this.x-another.x,2),Math.pow(this.y-another.y,2));
    }

}