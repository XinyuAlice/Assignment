/*CSCI1101-lab4-exercise1
the program is to set up RoomDimension first 
<Xinyu,Liu><B00783546><2018.2.8>*/
public class RoomDimension {
    //attributes
    public double length;
    public double width;
    //constructor
    RoomDimension(double l, double w) {

    }
    //get method
    public double getLength() {
        return length;
    }

    public double getWidth() {
        return width;
    }
    //set method
    public void setLength(double l) {
        length = l;

    }

    public void setWidth(double w) {
        width = w;
    }
    //toString
    public String toString() {
        String r = "";
        r += "Room with length:" + length + "\n";
        r += "Room with width:" + width + "\n";
        return r;
    }
}