/*CSCI1101-Assignment2
the program is about Robot,robot is seen as objects
<Xinyu,Liu><B00783546><2018.2.27>*/
public class Robot {
    //attributes
    public String name;
    public int row;
    public int col;
    //constructor
    public Robot() {//no args

    }

    public Robot(String n, int r, int c) {//with parameters
        name = n;
        row = r;
        r = 0;
        col = c;
        c = 0;

    }
    //get method(accessor)
    public String getName() {
        return name;
    }

    public int getRow() {
        return row;
    }

    public int getCol() {
        return col;
    }
    //set method(mutator)
    public void setName(String n) {
        name = n;
    }

    public void setRow(int r) {
        row = r;
    }

    public void setCol(int c) {
        col = c;
    }
    //move method
    public void move(int a, int b) {
        row = a;
        col = b;
    }
}
