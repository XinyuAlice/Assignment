/*CSCI1101-Assignment2
the program is about the track of the robot
<Xinyu,Liu><B00783546><2018.2.27>*/
public class Track {
    //attributes
    public int rownumber;
    public int colnumber;
    public String[][] track;
    //constructor
    public Track() {//no args

    }

    public Track(int r, int c) {//with parameters
        rownumber = r;
        colnumber = c;
        track = new String[rownumber][colnumber];
        for(int n=0;n<rownumber;n++){
           for(int i=0;i<colnumber;i++){
           }
        }
    }
    //get method
    public int getRownumber() {
        return rownumber;

    }

    public int getColnumber() {
        return colnumber;

    }
    //set method
    public void setRownumber(int r) {
        rownumber = r;

    }

    public void setColnumber(int c) {
        colnumber = c;
    }
    //PrintTrack method
    public void PrintTrack() {//empty
        for (int i = 0; i < rownumber; i++) {
            for (int j = 0; j < colnumber; j++) {

                System.out.print("_");

            }
          System.out.println();
        }
    }
    //PrintTrack:print the track with robots
    public void PrintTrack(Robot R, Robot P) {
        for (int i = 0; i < rownumber; i++) {
            for (int j = 0; j < colnumber; j++) {
                track[i][j] = "_";
            }
        }
        track[0][R.col] = R.name;
        track[1][P.col] = P.name;
        for (int i = 0; i < rownumber; i++) {
            for (int j = 0; j < colnumber; j++) {

                System.out.print(track[i][j] );
            }
            System.out.println();

        }

    }
}
