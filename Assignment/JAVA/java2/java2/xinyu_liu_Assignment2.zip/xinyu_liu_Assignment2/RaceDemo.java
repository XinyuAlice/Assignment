/*CSCI1101-Assignment2
the program is the demo of race
<Xinyu,Liu><B00783546><2018.2.27>*/
import java.util.Random;
import java.util.Scanner;

public class RaceDemo {

    public static void main(String[] args) {

        int l;
        Robot robot1 = new Robot();
        Robot robot2 = new Robot();
        Random r = new Random();
        Scanner kb = new Scanner(System.in);
        System.out.println("Welcome to the ROBOT RACE");
        System.out.println("Enter Robot 1 name:");//input robot1 name
        robot1.name = kb.next();
        System.out.println("Enter Robot 2 name:");//inout robot2 name
        robot2.name = kb.next();
        System.out.println("Enter the length of the race track:");//input race length
        l = kb.nextInt();
        Track track = new Track(2, l);//create track
        Race race = new Race(track, robot1, robot2);//create race
        System.out.println("Get Ready,Get Set,Go!");
        System.out.println("START RACE!");
        System.out.println(track.rownumber);//print total row
        System.out.println(track.colnumber);//print total col
        race.track.PrintTrack();
        robot1.move(0, 0);
        robot2.move(1, 0);
        track.PrintTrack(robot1, robot2);
        while (race.winner == false) {

            int n1 = r.nextInt(2);
            int n2 = r.nextInt(3);

            race.move(n1, n2);
            System.out.println("   Steps:" + n2);

            track.PrintTrack(robot1, robot2);
            race.winner();
            if (race.turn == 1) {
                race.turn = 2;
            }
            if (race.turn == 2) {
                race.turn = 1;
            }

        }
        System.out.println(race.winnerName + "  wins!!!!! ");//declare the winner
    }
}
