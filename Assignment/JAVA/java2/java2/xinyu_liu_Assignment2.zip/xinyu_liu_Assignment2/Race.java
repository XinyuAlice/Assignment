/*CSCI1101-Assignment2
the program is about the race of the robot game
<Xinyu,Liu><B00783546><2018.2.27>*/
public class Race {
    
    Track track = new Track();
    Robot robot1 = new Robot();
    Robot robot2 = new Robot();
    //attributes
    public boolean winner;
    public static int turn = 1;
    public String winnerName;
    //constructor
    public Race(){//no args
        
    }
    public Race(Track t, Robot r1, Robot r2) {//with parameters
        track = t;
        robot1 = r1;
        robot2 = r2;
        winner = false;

    }
    //get method
    public Track getTrack() {
        return track;
    }

    public Robot getRobot1() {
        return robot1;
    }

    public Robot getRobot2() {
        return robot2;
    }
    public boolean getWinner() {
        return winner;

    }
    //set method
    public void setTrack(Track t) {
        track = t;
    }

    public void setRobot1(Robot r1) {
        robot1 = r1;
    }

    public void setRobot2(Robot r2) {
        robot2 = r2;
    }

    public void setWinner(boolean w) {
        winner = w;
    }
    //move metod
    public void move(int direction, int step) {
        if (turn == 1) {

            System.out.print(robot1.name + "turn");
            if (direction == 0) {
                System.out.print("   Dir" + " forward     ");
                robot1.col += step;
                if (robot1.col >= track.colnumber) {
                    robot1.col = track.colnumber;
                }
            }

            if (direction == 1) {
                System.out.print("   Dir " + "Backward    ");
                robot1.col -= step;
                if (robot1.col <= 0) {
                    robot1.col = 0;
                }
            }

        }
        if (turn == 2) {
            System.out.print(robot2.name + " turn");
            if (direction == 0) {
                System.out.print("   Dir " + "Foraward    ");
                robot2.col += step;
                if (robot2.col >= track.colnumber) {
                    robot2.col = track.colnumber;
                }
            }
            if (direction == 1) {
                System.out.print("   Dir" + "Backward    ");
                robot2.col -= step;
                if (robot2.col <= 0) {
                    robot2.col = 0;
                }
            }

        }

    }
    //winner method
    public void winner() {
        if (robot1.col == track.colnumber - 1) {
            winner = true;
            winnerName = robot1.name;

        }
        if (robot2.col == track.colnumber - 1) {
            winner = true;
            winnerName = robot2.name;

        }
    }
}
