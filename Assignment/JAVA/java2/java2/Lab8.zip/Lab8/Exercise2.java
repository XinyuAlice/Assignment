/*CSCI1101-Lab8-exercise2
the program is to read the lines from this file using a Scanner object and then reformat the data and write the data using a PrintWriter object in a new file
<Xinyu,Liu><B00783546><2018.4.5>*/
import java.util.Scanner;
import java.io.*;
import java.text.DecimalFormat;
public class Exercise2 {

       public static void main (String [] args)throws IOException{
        Scanner kb=new Scanner(System.in);
        System.out.print("Enter the name of the file containing the marks for students: ");
        String filename=kb.nextLine();//enter the input file name
       
        File file = new File(filename);//create a new file
       

        if(!file.exists()){//check whether the file is exist or not
           System.out.println(filename+"doesn't exist");
           System.exit(0);
        }

        System.out.println("Enter the filename for output: ");//enter the name of output
        filename=kb.nextLine();
        PrintWriter outputFile=new PrintWriter(filename);//create a new txt
        Scanner inputFile = new Scanner(file);// read file
        int total=0,count=0;
        
        outputFile.printf("%-20s%-20s\r\n\r\n","Name","Ave Lab Mark\n\n");


        while(inputFile.hasNext()){//read information about students
            String fname=inputFile.next();
            String lname=inputFile.next();
            int mark=inputFile.nextInt()+inputFile.nextInt()+inputFile.nextInt()+inputFile.nextInt();
            double ave=1.0*mark/4;
            outputFile.println();
            outputFile.printf("%-20s%-20s%s\r\n",(lname+","+fname),ave,"\n");
            
            total+=mark;
            count++;
        }
        inputFile.close();//close file

        double average=0.0;//initialize the average
        if (count!=0)
            average=1.0*total/(count*4);//counting average of total marks
        DecimalFormat df = new DecimalFormat("#.0");//control number to two decimals
        outputFile.println();
        outputFile.printf("%-20s%-20s\r\n",("Total Student: "+count),("Ave Lab Mark: "+df.format(average)));
        outputFile.close();//close file

    }
}
