/*CSCI1101-Lab8-exercise1
the program is to include at least 4 buttons centered along the top of the window that will allow a user to change the colour of the lines
<Xinyu,Liu><B00783546><2018.4.5>*/
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.Group;
import javafx.scene.paint.Color;
import javafx.scene.shape.*;
import javafx.stage.Stage;
import javafx.scene.input.MouseEvent;
import javafx.scene.control.Button;
import javafx.event.ActionEvent;
import javafx.geometry.Pos;
import javafx.scene.layout.FlowPane;
import javafx.scene.paint.Paint;

public class Exercise1 extends Application {
   //attributes
    private Line line;
    private Group root;
    private Button b1, b2, b3, b4;
    private FlowPane pane;
    private Paint value;
    @Override
    public void start(Stage primaryStage) {

        root = new Group();
        //set buttons
        b1 = new Button("RED");
        b1.setStyle("-fx-font:20 Arial");

        b2 = new Button("BLUE");
        b2.setStyle("-fx-font:20 Arial");
        b3 = new Button("GREEN");
        b3.setStyle("-fx-font:20 Arial");
        b4 = new Button("PURPLE");
        b4.setStyle("-fx-font:20 Arial");
        b1.setOnAction(this::processButtonPress);
        b2.setOnAction(this::processButtonPress);
        b3.setOnAction(this::processButtonPress);
        b4.setOnAction(this::processButtonPress);
        //create pane
        pane = new FlowPane();
        root.getChildren().add(pane);
        pane.setStyle("-fx-background-color:LIGHTBLUE");
        
        pane.getChildren().addAll(b1,b2,b3,b4);
        pane.setAlignment(Pos.TOP_CENTER);//set buttons location
        //create a scene
        Scene scene = new Scene(root, 500, 500, Color.LIGHTBLUE);
        
        scene.setOnMousePressed(this::processMousePress);
        scene.setOnMouseDragged(this::processMouseDrag);
        primaryStage.setTitle("Elastic Lines");//create title
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    public void processMousePress(MouseEvent e) {//press mouse
        line = new Line(e.getX(), e.getY(), e.getX(), e.getY());
        root.getChildren().add(line);
        line.setStrokeWidth(3);
        line.setStroke(value);
    }

    public void processMouseDrag(MouseEvent e) {//drag mouse
        line.setEndX(e.getX());
        line.setEndY(e.getY());

    }

    public void processButtonPress(ActionEvent event) {//button action
        if (event.getSource() == b1) {
            value=Color.RED;
        }
        if (event.getSource() == b2) {
            value=Color.BLUE;
        }
        if (event.getSource() == b3) {
            value=Color.GREEN;
        }
        if (event.getSource() == b4) {
          value=Color.PURPLE;
        }
    }

    public static void main(String[] args) {
        Application.launch(args);
    }

}
