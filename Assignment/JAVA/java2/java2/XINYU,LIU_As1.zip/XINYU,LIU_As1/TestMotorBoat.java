/*CSCI1101-Assignment1-exercise2
the program is to test motorboat
<Xinyu,Liu><B00783546><2018.2.2>*/
public class TestMotorBoat {

    
    public static void main(String args[]) {
        //create the first motorboat
        MotorBoat MotorBoat1 = new MotorBoat("Speedy", 70, 60, 130, 0.45, 70);
        MotorBoat1.cruise(0.5);//set the time 
        System.out.println(MotorBoat1.toString());
        MotorBoat1.changeSpeed(45);//set the changeSpeed
        MotorBoat1.cruise(0.5);//set the time 
        System.out.println(MotorBoat1.toString());
        //create the second motorboat
        MotorBoat MotorBoat2 = new MotorBoat("Flippy", 80, 65, 100, 0.65, 60);
        MotorBoat2.cruise(1.0 / 3);//set the time
        System.out.println(MotorBoat2.toString());
        MotorBoat2.increaseFuel(65);//increase the fuel
        MotorBoat2.changeSpeed(45);//set the change
        MotorBoat2.cruise(0.4);//set the time
        System.out.println(MotorBoat2.toString());
        boolean fast = MotorBoat1.fasterBoat(MotorBoat2);//compare speed
        if (fast == true) {
            System.out.println("Fastest Boat:Speedy");
        }
        if (fast == false) {
            System.out.println("Fastest Boat:Flippy");
        }
        boolean same = MotorBoat1.equals(MotorBoat2);//compare whether the two motorboats are same
        if (same == true) {
            System.out.println("Speedy and Flippy are the same boat");
        }
        if (same == false) {
            System.out.println("Speedy and Flippy are not the same boat");
        }
    }
}