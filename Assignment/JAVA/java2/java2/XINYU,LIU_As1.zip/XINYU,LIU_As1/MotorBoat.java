/*CSCI1101-Assignment1-exercise2
the program is to use motorboat as object
<Xinyu,Liu><B00783546><2018.2.2>*/
public class MotorBoat {

    //attributes
    private String name;
    private int capacity;
    private double currentAmount;
    private int maxSpeed;
    private double currentSpeed;
    private double rateofConsumption;
    private double distanceTraveled;

    //constructor
    MotorBoat(String n, int c, double ca, int ms, double r, double cs) {
        name = n;
        capacity = c;
        currentAmount = ca;
        maxSpeed = ms;
        rateofConsumption = r;
        currentSpeed = 0;
        currentSpeed = cs;
    }

    //get and set methods
    public void changeSpeed(double change) {

        if ((currentSpeed + change) > maxSpeed) {
            currentSpeed = maxSpeed;
        } else {
            currentSpeed += change;
        }

    }

    //set method
    public void cruise(double t) {
        distanceTraveled = t * currentSpeed;

        currentAmount = currentAmount - t * currentSpeed * rateofConsumption;
    }
    //increaseFuel
    public void increaseFuel(double refuel) {

        if ((currentAmount + refuel > capacity)) {
            currentAmount = capacity;
        } else {
            currentAmount += refuel;
        }

    }
   //boolean which boat is faster
    public boolean fasterBoat(MotorBoat s) {
        if (maxSpeed > s.maxSpeed) {
            return true;
        } else {
            return false;
        }

    }
    //boolean whether the two boats are equal
    public boolean equals(MotorBoat a) {
        if (maxSpeed == a.maxSpeed && capacity == a.capacity && rateofConsumption == a.rateofConsumption) {
            return true;
        } else {
            return false;
        }
    }
    //toString
    public String toString() {
        String r = "";
        r += "name:" + name + "\n";
        r += "current speed:" + currentSpeed + "kmph\n";
        r += "distance traveled so far :" + distanceTraveled + "km\n";
        r += "the amount of fuel left in the tank:" + currentAmount + "litres\n";
        return r;
    }
}