/*CSCI1101-Assignment1-exercise1
the program is to use door as object to determine the condition of the door 
<Xinyu,Liu><B00783546><2018.2.2>*/
public class Door {

    //attributes
    public String inscription;
    public boolean locked;
    public boolean closed;
    //constructor
    Door(String ins,boolean l,boolean c){
        inscription=ins;
        locked=l;
        closed=c;
       
    }
    //boolean method
    public boolean  isClosed(){//isClosed
      if(closed==true)
          return true;
      else 
          return false;
}
    public boolean isLocked(){//isLocked
        if(locked==true)
          return true;
      else 
          return false;
    }
    public void open(){//open method to check whether the door is open
        if(closed==true&&locked==false)
            closed=false;
    }
    public void close(){//close method to check whether the door is closed
        if(closed==false&&locked==false)
            closed=true;
    }
    public void lock(){//lock method to check whether the door is locked

        if(locked=false)
            locked=true;
    }
    public void unlock(){//unlock method to check whether the door is unlocked
        if(locked==true&&closed==true)
            locked=false;
     }
    public String toString(String r){//toString method
        r="";
        r+="display inscription"+inscription+"\n";
        r+="the door is closed:"+closed+"\n";
        r+="the door is locked"+locked+"\n";
        return r;
    }
    
}
