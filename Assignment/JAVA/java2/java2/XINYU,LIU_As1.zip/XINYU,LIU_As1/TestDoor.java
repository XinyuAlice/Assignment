/*CSCI1101-Assignment1-exercise1
the program is to test door condition 
<Xinyu,Liu><B00783546><2018.2.2>*/
import java.util.Scanner;
import java.util.Random;

public class TestDoor {

    public static void main(String args[]) {
        boolean key = false;
        String ins = null;
        boolean enterOpen = false;
        Scanner kb = new Scanner(System.in);

        System.out.print("Welcome to the Dungeon.");//start the game
        ss:for(int i=1;i<=10000;i++){//set a label: ss
        System.out.print("Play? (Enter Y or N):");//input Y or N
        String a = kb.nextLine();
        
        while ("Y".equals(a)) {
            
            int number = (int) (Math.random() * 3);//random the door and key
            if (number == 0) {
                ins = "Enter";
                key = true;
            }
            if (number == 1) {
                ins = "Exit";
                key = false;
            }
            if (number == 2) {
                ins = "Treasure";
            }
            System.out.println("Door:" + ins);
            System.out.println("Key:" + key);
            if ("Enter".equals(ins) && key == true) {
                System.out.println("ENTER");
                enterOpen = true;
                
            }
            if ("Enter".equals(ins) && key == false) {
                System.out.println("Sorry,cannot unlock");
                enterOpen = false;
            }
            if ("Treasure".equals(ins) && key == true) {
                if (enterOpen == true) {
                    System.out.println("GET THE TREASURE");
                } else {
                    System.out.println("Sorry. Cannot get to Treasure without entering");
                }

            }
            if ("Treasure".equals(ins) && key == false) {
                System.out.println("Sorry.Cannot unlock");
            }
            if ("Exit".equals(ins) && key == true) {
                if (enterOpen == true) {
                    System.out.println("EXITED");
                } else {
                    System.out.println("Sorry. Cannot exit without entering");
                }

            }
            if ("Exit".equals(ins) && key == false) {
                System.out.println("Sorry.Cannot unlock");

            }
            continue ss;//cotinue,jump to the first line of for loop
        }
        
        if("N".equals(a))//until a="N",end for loop
            System.out.print("Goodbye!");
          break ss;//end the loop
        
        }   
  }//end main
}//end class:TestDoor