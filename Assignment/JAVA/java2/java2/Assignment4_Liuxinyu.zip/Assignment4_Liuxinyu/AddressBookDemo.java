/*CSCI1101-Assignment4-demo
the program is the demo of AddressBook
<Xinyu,Liu><B00783546><2018.4.5>*/
import java.util.Scanner;


public class AddressBookDemo {

    public static void main(String[] args) {
        Scanner kb = new Scanner(System.in);
        AddressBook aB = new AddressBook();//create a new addressbook
        Boolean quit = false;
        String l, f, s, phone;
        OUTER:
        while (!quit) {//create a loop
            System.out.println("Enter 1 to add contact, 2 to display, 3 to search, 4 to delete, 5 to quit:");//input a request
            int input = kb.nextInt();
            while (input < 1 || input > 5) {//ensures number is between 1 and 5
                System.out.println("Invalid option.");
                System.out.print("Enter 1 to add contact, 2 to display, 3 to search, 4 to delete or 5 to quit: ");
                input = kb.nextInt();
            }
            switch (input) {
                case 1://when input is 1
                    System.out.println("Enter last name: ");

                    l = kb.next();

                    System.out.println("Enter first name: ");
                    f = kb.next();
                    System.out.println("Enter Street name:");
                    s = kb.next();
                    System.out.println("Enter phone number:");

                    phone = kb.next();
                    Contact contact = new Contact(l, f, s, phone);//create a new contact

                    if (aB.nodupilicate(contact)) {//to avoid enter the same information

                        continue;
                    } else {
                        aB.addContact(contact);//add contact to the addressbook

                        break;
                    }
                case 2:
                    aB.displayAllContacts();//display all the contacts
                    break;
                case 3:
                    System.out.print("Enter 1 to search first name, 2 to search address, 3 to search phone number : ");//select a method to choose
                    String searchq = kb.next();
                    int searchFor = Integer.valueOf(searchq);//transfer string to int value
                    System.out.print("Enter what to search : ");
                    String search = kb.next();
                    aB.Search(search, searchFor);//search method
                    break;
                case 4:
                   
                    aB.deleteContact();//delete contact
                    break;
                case 5:
                    quit = true;
                    System.out.println("Good bye.");
                    break OUTER;
                default:
                    break;
            }
        }

    }
}
