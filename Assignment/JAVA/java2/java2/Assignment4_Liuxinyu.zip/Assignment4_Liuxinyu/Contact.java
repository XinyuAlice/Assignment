/*CSCI1101-Assignment4-Contact
the program is to hold a person��s last name, first name, street name, and phone number
<Xinyu,Liu><B00783546><2018.4.5>*/



public class Contact {
    //attributes
    private String lastName;
    private String firstName;
    private String streetName;
    private String phone;
    //constructor
    public Contact() {

    }
    //constructor with parameter
    public Contact(String lastN, String firstN, String streetN, String p) {
        lastName = lastN;
        firstName = firstN;
        streetName = streetN;
        phone = p;

    }
    //equal method
    public boolean equals(Contact c) {
        if (this.lastName.equals(c.getLastName()) && this.firstName.equals(c.getFirstName()) && this.streetName.equals(c.getStreetName())) {
            return true;
        } else {
            return false;
        }
    }
    //get method 
    public String getLastName() {
        return lastName;
    }

    public String getFirstName() {
        return firstName;
    }

    public String getStreetName() {
        return streetName;
    }

    public String getPhone() {
        return phone;
    }
    //set method
    public void setLastName(String lastN) {
        lastName = lastN;
    }

    public void setFirstName(String firstN) {
        firstName = firstN;
    }

    public void setStreetName(String streetN) {
        streetName = streetN;
    }

    public void setPhone(String p) {
        phone = p;
    }
    //toString method
    public String toString() {

        return this.lastName + "," + this.firstName + "\t\t\t" + this.streetName + "\t\t\t" + this.phone;

    }

}
