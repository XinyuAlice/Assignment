/*CSCI1101-Assignment4-Node
the program is to hold Contact as its data
<Xinyu,Liu><B00783546><2018.4.5>*/
public class Node {
    //attributes
    private Contact contact;
    private Node next;
    //constructor
    public Node(Contact c, Node n) {
        contact = c;
        next = n;
    }
    //get method
    public Contact getContact() {
        return contact;
    }

    public Node getNext() {
        return next;
    }
    //set method 
    public void setContact(Contact c) {
        contact = c;
    }

    public void setNext(Node n) {
        next = n;
    }
    //String method
    public String toString() {
        return contact + "-->";
    }
}
