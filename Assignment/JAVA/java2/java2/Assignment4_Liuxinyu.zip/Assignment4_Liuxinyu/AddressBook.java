/*CSCI1101-Assignment4-Addressbook
the program is to add a contact, display all contacts, search for a specific contact and display it, or search and delete a specific contact
<Xinyu,Liu><B00783546><2018.4.5>*/
import java.util.Scanner;

public class AddressBook {
    //attribute
    LinkedList list;//create a list
    //constructor
    public AddressBook() {
        list = new LinkedList();
    }
    //nodupilicate:to avoid enter the same method
    public boolean nodupilicate(Contact c) {
        Node p = list.getFront();
        boolean duplicate = false;
        while (!duplicate && p != null) {

            if (c.getLastName().equals(p.getContact().getLastName()) && c.getFirstName().equals(p.getContact().getFirstName()) && c.getStreetName().equals(p.getContact().getStreetName()) && c.getPhone().equals(p.getContact().getPhone())) {
                System.out.println("Same information-cannot add");

                duplicate = true;
                break;
            }
            p = p.getNext();

        }

        return duplicate;

    }
    //add contact in alphabetical order
    public void addContact(Contact c) {
        Node n = new Node(c, null);
        if (list.getCount() == 0) {//list is null
            list.setFront(n);
            list.setCount(1);
        } else {
            Node p = list.getFront();//use two nodes to compare the size of the first name and last name
            Node q = p.getNext();

            if (q == null) {//when the list only have one node
                if (order(n, p)) {//new node bigger than front add to end 
                    list.addToEnd(n.getContact());//add to end 
                } else {//if smaller add to front
                    list.addToFront(n.getContact());//add to front
                }
            } else {//if list have more than 2 node
                boolean added = false;//check if add 
                while (q != null) {
                    if (order(p, n)) {//if n is smaller then add to front
                        list.addToFront(n.getContact());
                        added = true;
                        break;
                    } else if (order(n, p)) {
                    //if n is bigger than p and q then refresh p and q
                        if (order(n, q)) {

                            p = p.getNext();
                            q = q.getNext();
                            continue;
                        } else if (order(q, n)) {//if n bigger than p and smaller than q then add between them
                            p.setNext(n);
                            n.setNext(q);
                            list.setCount(list.getCount() + 1);
                            added = true;
                            break;
                        }
                    }
                }
                if (added == false) {//if compare to end but still not add,then add to the end 
                    list.addToEnd(n.getContact());
                }
            }
        }
    }
    //order method to compare the lastname and then first name
    public boolean order(Node a, Node b) {
        boolean result = false;
        //first compare last name: which is bigger
        if (a.getContact().getLastName().compareTo(b.getContact().getLastName()) > 0) {
            result = true;
        //when last name is the same then compare the first name
        } else if (a.getContact().getLastName().compareTo(b.getContact().getLastName()) == 0) {
            if (a.getContact().getFirstName().compareTo(b.getContact().getFirstName()) >= 0) {
                result = true;
            } else {
                result = false;
            }
        } else {//compare the last name which is bigger
            result = false;
        }
        return result;
    }

  
   //getlist method
    public LinkedList getList() {
        return list;
    }
    //search method
    public void Search(String d, int searchFor) {
        boolean search=false;
        Node curr = list.getFront();
       
        switch (searchFor) {
            case 1://search by name
                while (curr != null) {
                    if (curr.getContact().getFirstName().contains(d)) {
                       
                        System.out.println(curr.getContact().toString());
                    }
                    curr = curr.getNext();
                }
                break;
            case 2://search by street name
                while (curr != null) {
                    if (curr.getContact().getStreetName().contains(d)) {
                        
                        System.out.println(curr.getContact().toString());
                    }
                    curr = curr.getNext();
                }
                break;
            case 3://search by phone 
                while (curr != null) {
                    if (curr.getContact().getPhone().contains(d)) {
                       
                        System.out.println(curr.getContact().toString());
                    }
                    curr = curr.getNext();
                }
                break;
            default:
                if (curr == null) {
                    System.out.print("Cannot search-empty");
                } else {
                    System.out.println("Sorry-cannot find");
                }

                break;
        }
    }
    
    //display method
    public void displayAllContacts() {//dispaly the contacts
        System.out.println();
        System.out.println("Name\t\t\t\tStreet\t\t\tNumber");

        Node curr = list.getFront();
        if (curr == null) {
            System.out.println("empty list-cannot display");
        }
        while (curr != null) {

            System.out.println(curr.getContact().toString());

            curr = curr.getNext();

        }

    }
    //delete contact
    public void deleteContact() {
        System.out.println();
        if (list.size() == 0)//if list is empty, it would say there is no contact
        {
            System.out.print("No contacts to delete.");
        } else {
            int counter = 1;
            int toDelete;
            Scanner kb = new Scanner(System.in);
            Node curr = list.getFront();
            System.out.println("Name\t\t\t\tStreet\t\t\tNumber");//displays title
            while (curr != null) {
                System.out.println(counter + ". " + curr);//displays number of contact and contact toString
                counter++;//increases counter
                curr = curr.getNext();
            }
            
            System.out.print("\nEntry to delete: ");//user enter the number
            toDelete = kb.nextInt();
            while (toDelete < 0 || toDelete > list.getCount()) {//ensures that there will not be any errors
                System.out.print("Entry must be within specific values. Entry to delete ");
                toDelete = kb.nextInt();
            }
            list.remove(toDelete-1 );//removes contact
        }
    }

}
