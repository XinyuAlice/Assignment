/*CSCI1101-Assignment4-Linkedlist
the program is to work with Nodes with Contacts as its data
<Xinyu,Liu><B00783546><2018.4.5>*/
public class LinkedList {
    //attributes
    private Node front;
    private int count;
   
    //constructor 

    public LinkedList() {
        front = null;
        count = 0;
    }
    //add a node to the front of the linked list 

    public void addToFront(Contact c) {
        Node n;
        n = new Node(c, null);
        if (count == 0) {
            setFront(n);
        } else {
            n = new Node(c, front);
            front = n;
            count++;
        }
    }

    //get the current size of the list 
    public int size() {
        return count;
    }
    //check if the list is empty 

    public boolean isEmpty() {
        return (count == 0);
    }
    //clear the list 

    public void clear() {
        front = null;
        count = 0;
    }
    //get the content of the first node 

    public Contact getFrontData() {
        if (front == null) {
            System.out.println("Empty list");
            return null;
        } else {
            return front.getContact();

        }
    }
    // get the first node 

    public Node getFront() {
        return front;
    }
    //get the count of the list
    public int getCount() {
        return count;
    }
    //set the first node
    public void setFront(Node front) {
        this.front = front;
    } 
    //set the count of the list
    public void setCount(int n) {
        count = n;
    }
    //scan the list and print contents 

    public void enumerate() {
        Node curr = front;
        while (curr != null) {
            System.out.print(curr);
            curr = curr.getNext();
        }
        System.out.println(".");
    }
    //set method 
    public void set(int j, Contact c) {
        if (j < 0 || j > size()) {
            System.out.println("Cannot set-out of bounds");

        } else if (j == 0) {
            addToFront(c);
        } else {
            Node curr = front;
            for (int i = 0; i < j - 1; j++) {
                curr = curr.getNext();
            }
            Node n = new Node(c, curr.getNext());
            curr.setNext(n);
            count++;
        }
    }
    //remove front node
    public void removeFront() {

        if (!isEmpty()) {
            
            front = front.getNext();
            count--;
          
        } else {
            System.out.println("Cannot remove-empty list");
        }

    }
    //remove last node
    public void removeLast() {
        if (isEmpty()) {
            System.out.println("Cannot remove-empty list");
        } else if (front.getNext() == null) {
            front = null;
            count--;
            
        } else {
            Node curr = front;
            while (curr.getNext().getNext() != null) {
                curr = curr.getNext();
            }
            curr.setNext(null);
            count--;
            
        }

    }
    //remove method
    public void remove(int index) {
        
        if (index < 0 || index > size()) {
            System.out.println("Cannot remove,empty list");
        } else if (index == 0) {
            // Remove the first item in the list
            removeFront();
            count--;

        } else if (index == size() - 1) {
            //remove the last item in the list
            removeLast();
           
        } 
        else {

            Node curr = front;

            for (int k = 0; k < index - 1; k++) 
                curr = curr.getNext();

            
            curr.setNext(curr.getNext().getNext());
            count--;

        }
    
    }
    //add item to end
    public void addToEnd(Contact c) {
        Node n = new Node(c, null);
        if (isEmpty()) {
            front = n;
        } else {
            Node curr = front;
            while (curr.getNext() != null) {
                curr = curr.getNext();
            }
            curr.setNext(n);
        }
        count++;
    } 
    //add method
    public void add(int index, Contact c) {
        if (index < 0 || index > size()) {
            System.out.println("Can't add. Index out of bounds");
        } else {

            if (index == 0) {
                addToFront(c);
            } else {
                Node curr = front;
                for (int i = 0; i < index - 1; i++) {
                    curr = curr.getNext();
                }
                Node n = new Node(c, curr.getNext());
                curr.setNext(n);
                count++;
            }
        }
    }
}
