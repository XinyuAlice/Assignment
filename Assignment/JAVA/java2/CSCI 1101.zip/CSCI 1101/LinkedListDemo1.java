//class LinkedListDemo1 
public class LinkedListDemo2 { 
  public static void main(String[] args) { 
      LinkedList2 myList = new LinkedList2(); 
      myList.addToFront("Toronto"); 
      myList.addToFront("New York"); 
      myList.addToFront("Calgary"); 
      myList.addToFront("Halifax");
      myList.addToFront("St.John's");
      System.out.println("Number of nodes in the list: "+ myList.size()); myList.enumerate();
      myList.addToFront("Vancouver");
      myList.addToFront("Montreal");
      myList.enumerate(); 
  } 
} 
