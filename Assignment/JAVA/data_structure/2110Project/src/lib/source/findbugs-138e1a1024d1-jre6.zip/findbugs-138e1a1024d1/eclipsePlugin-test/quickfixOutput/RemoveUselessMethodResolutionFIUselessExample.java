public class RemoveUselessMethodResolutionFIUselessExample {
}
