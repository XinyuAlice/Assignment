import java.net.URL;
import java.net.URLClassLoader;

public class CreateDoPrivilegedBlockResolutionExample {
    public void createClassLoader() {
        new URLClassLoader(new URL[] {});
    }
}
