public class CreateAndOddnessCheckResolutionExample {
    public boolean isOdd(int value) {
        return (value & 1) == 1;
    }
}
