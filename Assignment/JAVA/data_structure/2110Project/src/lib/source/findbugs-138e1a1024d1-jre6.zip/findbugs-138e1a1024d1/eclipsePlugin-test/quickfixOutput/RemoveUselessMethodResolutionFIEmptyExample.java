public class RemoveUselessMethodResolutionFIEmptyExample {
}
