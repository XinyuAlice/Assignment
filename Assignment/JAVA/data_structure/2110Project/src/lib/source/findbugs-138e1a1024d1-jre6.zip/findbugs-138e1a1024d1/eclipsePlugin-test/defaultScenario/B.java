public class B {
    // should report URF_UNREAD_FIELD (UrF) and DM_STRING_CTOR (Dm)
    String s = new String("");
}
