/**
 * JobsController
 *
 * @description :: Server-side actions for handling incoming requests.
 * @help        :: See https://sailsjs.com/docs/concepts/actions
 */



//const Jobs = require('../models/Jobs');

let jobs546 = [
  { jobName: 'Job1546', partId: 3546, qty: 55 },
  { jobName: 'Job1546', partId: 4546, qty: 35 },
  { jobName: 'Job2546', partId: 4546, qty: 33 },
  { jobName: 'Job3546', partId: 5546, qty: 46 },
];

//const Jobs = require('../models/Jobs');
//let db546 = sails.getDatastore();

module.exports = {
  getJobs546: function (req, res) {
    //   Jobs.find().exec((err, jobs546) => {
    //     if (err) {
    //       res546.send(500, { err: 'Database Error' });
    //     }
    //     return res546.send(jobs546);
    //   });

    //  let sql546 = 'SELECT * FROM jobs546';
    // Jobs.sendNativeQuery(sql546, (err, jobs546) => {
    //   if (err) {
    //     throw err;
    //   }
    //   res546.send(jobs546.rows);
    // });

    // let query546 = db546.sendNativeQuery(sql546).exec((err, jobs546) => {
    //   if (err) {
    //     throw err;
    //   }
    //   res546.send(jobs546.rows);
    // });
    res.send(jobs546);
  },
  getJobs546ByID: function (req, res) {

    const job546 = jobs546.find((c) => (c.jobName === (req.params.jobName) && (c.partId === parseInt(req.params.partId))));
    if (!job546) { return res.status(404).send('The job with the given jobName and partId was not found'); }
    res.send(job546);
    // let wherejob546 = 'jobName= ?';
    // let wherepartid546 = 'partId= ?';
    // let sql546 = 'SELECT * FROM jobs546 WHERE ' + wherejob546 + 'AND ' + wherepartid546;
    // let values546 = [req546.params.jobName, req546.params.partId];

    // console.log(sql546);
    // console.log(values546);

    // let query546 = db546.sendNativeQuery(sql546, values546, (err, result546) => {
    //   if (err) {
    //     throw err;
    //   }
    //   console.log(result546);
    //   if (!result546) { res546.status(404).send('Job with jobName: ' + req546.params.jobName + ' and PartId: ' + req546.params.partId + ' was not found'); }
    //   res546.send('Data retrieved with input jobName and partId');
    // });
  },
  addJobs546: function (req, res) {

    const job546 = jobs546.find(c => (c.jobName === (req.body.jobName) && (c.partId === parseInt(req.body.partId))));
    if (!job546) {

      const j546 = {
        jobName: req.body.jobName,
        partId: req.body.partId,
        qty: req.body.qty
      };
      jobs546.push(j546);

      res.send(jobs546[jobs546.length - 1]);
    }
    else {
      res.status(404).send('The job with the given jobName' + req.body.jobName + 'and partId' + req.body.partId + 'exists already');
    }
    // let wherejob546 = 'jobName= ?';
    // let wherepartid546 = 'partId= ?';
    // let sqlSelect546 = 'SELECT * FROM jobs546 WHERE ' + wherejob546 + 'AND ' + wherepartid546;
    // let values546 = [req546.body.jobName, req546.body.partId];
    // let sql546 = 'INSERT INTO jobs546 SET ?';
    // let data546 = { jobName: req546.body.jobName, partId: req546.body.partId, qty: req546.body.qty };
    // let querySelect546 = db546.sendNativeQuery(sqlSelect546, values546, (err546, result546) => {

    //   if (result546 === '') {
    //     let query546 = db546.sendNativeQuery(sql546, data546, (err546, jobs546) => {
    //       if (err546) {
    //         throw err546;
    //       }
    //       res546.send('Data {' + data546.jobName + ',' + data546.partId + ',' + data546.qty + '}inserted in the table');
    //       console.log(jobs546);
    //     });
    //   }
    //   else { res546.status(404).send('The job with the given jobName ' + req546.body.jobName + ' and partId ' + req546.body.partId + ' exists already'); }
    // });


  },
  viewData546: function (req, res) {
    if (!jobs546) {
      res.send('Cannot find anything to show');
    }
    if (jobs546) {
      res.view('\\pages\\viewData546', { jobs546: jobs546 });
    }
    // Jobs.find().exec((err, jobs546) => {
    //   if (err) {
    //     res.send(500, 'Query failed');
    //   }
    //   res.view('\\pages\\viewData546', { jobs546: jobs546 });
    // });
  },
  addData546: function (req, res) {
    const job546 = jobs546.find(c => (c.jobName === (req.body.jobName) && (c.partId === parseInt(req.body.partId))));
    if (!job546) {

      const j546 = {
        jobName: req.body.jobName,
        partId: req.body.partId,
        qty: req.body.qty
      };
      jobs546.push(j546);
      res.redirect('/viewData546');

    }
    else {
      res.status(404).send('The job with the given jobName' + req.body.jobName + 'and partId' + req.body.partId + 'exists already');
    }
  }

  //   let wherejob546 = 'jobName= ?';
  //   let wherepartid546 = 'partId= ?';
  //   let sqlSelect546 = 'SELECT * FROM jobs546 WHERE ' + wherejob546 + 'AND ' + wherepartid546;
  //   let values546 = [req546.body.jobName, req546.body.partId];
  //   let sql546 = 'INSERT INTO jobs546 SET ?';
  //   let data546 = { jobName: req546.body.jobName, partId: req546.body.partId, qty: req546.body.qty };
  //   let querySelect546 = db546.sendNativeQuery(sqlSelect546, values546, (err546, result546) => {

  //     if (result546 === '') {
  //       let query546 = db546.sendNativeQuery(sql546, data546, (err546, jobs546) => {
  //         if (err546) {
  //           throw err546;
  //         }
  //         res546.send('Data {' + data546.jobName + ',' + data546.partId + ',' + data546.qty + '}inserted in the table');
  //         console.log(jobs546);
  //         res.redirect('/viewData546');
  //       });
  //     }
  //     else {
  //       res546.status(404).send('The job with the given jobName ' + req546.body.jobName + ' and partId ' + req546.body.partId + ' exists already');
  //     }
  //   });
  // }

};





